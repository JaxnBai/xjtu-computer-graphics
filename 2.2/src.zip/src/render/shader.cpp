#include "shader.h"
#include "../utils/math.hpp"

#ifdef _WIN32
#undef min
#undef max
#endif

using Eigen::Vector3f;
using Eigen::Vector4f;
using Eigen::Matrix4f;

// vertex shader & fragement shader can visit
// all the static variables below from Uniforms structure
Eigen::Matrix4f Uniforms::MVP;
Eigen::Matrix4f Uniforms::inv_trans_M;
int Uniforms::width;
int Uniforms::height;

// vertex shader
VertexShaderPayload vertex_shader(const VertexShaderPayload& payload)
{
    VertexShaderPayload output_payload = payload;
    
    Vector4f clip= Uniforms::MVP*payload.position;
    for(int i=0;i<4;i++)
        clip(i)=clip(i)/clip(3);
    
    // Vertex position transformation
    Eigen::Matrix4f a=Eigen::Matrix4f::Identity();
    a(0,0)=Uniforms::width/2;
    a(1,1)=Uniforms::height/2;
    a(0,3)=Uniforms::width/2;
    a(1,3)=Uniforms::height/2;
    output_payload.position=a*clip;
    // Viewport transformation
    Vector4f n(payload.normal(0),payload.normal(1),payload.normal(2),1);
    n=Uniforms::inv_trans_M*n;
    for(int i=0;i<3;i++)
    output_payload.normal(i)=n(i)/n(3);
    // Vertex normal transformation
    

    return output_payload;
}

Vector3f phong_fragment_shader(const FragmentShaderPayload& payload, GL::Material material,
                               const std::list<Light>& lights, Camera camera)
{
    //参考文献：https://blog.csdn.net/qq_40297109/article/details/124435570
    //参考文献：https://www.cnblogs.com/lawliet12/p/17719365.html
    //参考文献：https://zhuanlan.zhihu.com/p/452687345

    Eigen::Vector3f ka = material.ambient;
    Eigen::Vector3f kd = material.diffuse;
    Eigen::Vector3f ks = material.specular;
    
    Eigen::Vector3f point = payload.world_pos;
    Eigen::Vector3f normal = payload.world_normal;
    Eigen::Vector3f eye_pos= camera.position;
    Eigen::Vector3f amb_light_intensity={1,1,1};
    Eigen::Vector3f result_color = {0, 0, 0};

     Vector3f La ;    // 环境光 
    for(int i=0;i<3;i++)
    {
        La(i)=ka(i)*amb_light_intensity(i);
    }
    result_color += La;
    for (auto& light : lights)
    {
        // TODO: For each light source in the code, calculate what the *ambient*, *diffuse*, and *specular* 
        // components are. Then, accumulate that result on the *result_color* object.
        Vector3f lightPos = light.position;
        
        float r = (lightPos - point).dot(lightPos - point);

        Vector3f n = normal.normalized();    //n向量
        Vector3f l = (lightPos - point).normalized();   //l向量
        Vector3f v = (eye_pos - point).normalized();    //v向量
        Vector3f h = (v + l).normalized();  //h向量

        Vector3f Ld = kd*(light.intensity / r) * std::max(0.0f, n.dot(l));
        Vector3f Ls = ks*(light.intensity / r) * std::pow(std::max(0.0f, n.dot(h)), material.shininess);

        result_color += Ld;
        result_color += Ls;
    }
   
    for(int i=0;i<3;i++)
    {
        if(result_color(i)<0)result_color(i)=0;
        if(result_color(i)>1)result_color(i)=1;
    }
    printf("result_color:%f %f %f\n",result_color(0),result_color(1),result_color(2));
    return result_color * 255.f;
    
    // ka,kd,ks can be got from material.ambient,material.diffuse,material.specular
    

    // set ambient light intensity

    // Light Direction
        
    // View Direction
        
    // Half Vector
        
    // Light Attenuation
        
    // Ambient
        
    // Diffuse
        
    // Specular
        
    // set rendering result max threshold to 255
    
}
